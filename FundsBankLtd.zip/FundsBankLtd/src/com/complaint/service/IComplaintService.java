package com.complaint.service;

import com.complaint.bean.ComplaintBean;


public interface IComplaintService {
	public int addComplaintDetails(ComplaintBean bean);
	public ComplaintBean checkStatus(int complaintId);
}
