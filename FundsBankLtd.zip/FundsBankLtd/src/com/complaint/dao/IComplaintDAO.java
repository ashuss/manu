package com.complaint.dao;

import java.util.List;

import com.complaint.bean.ComplaintBean;


public interface IComplaintDAO {

	public int addComplaintDetails(ComplaintBean bean);
	
	public ComplaintBean checkStatus(int complaintId);
}
